import java.util.Scanner;

public class registration {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=== Registration and Login ===");

        // Registration
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter a username (must contain an underscore and be "
                + "no more than five characters long): ");
        String username = scanner.nextLine();

        System.out.print("Enter a password (at least eight characters, one capital "
                + "letter, one number and one special character): ");
        String password = scanner.nextLine();

        System.out.print("Enter your cell phone number (must include the "
                + "international country code, e.g. +27...): ");
        String cellNumber = scanner.nextLine();

        String registrationMessage = login.registerUser(username, password, cellNumber,
                firstName, lastName);
        System.out.println(registrationMessage);

        // Login
        System.out.println();
        System.out.println("=== Login ===");

        System.out.print("Enter your username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccessful = login.loginUser(loginUsername, loginPassword);
        String loginMessage = login.returnLoginStatus(loginSuccessful);
        System.out.println(loginMessage);

        scanner.close();
    }
}
